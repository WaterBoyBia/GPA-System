package stdinfo;

import java.util.*;


public class GPA {
    public static void main(String[] args)
    {
        int a;
        Scanner in=new Scanner(System.in);
        System.out.print("  GPA计算系统  \n"
                +"  [1]进入系统  \n"
                +"  [0]退出  \n"
                +"您的选择为："
        );
        a=in.nextInt();
        if(a==1) {
            System.out.print("请输入需要统计的课程数目：");
            int coursenum=in.nextInt();
            Course[] g=new Course[coursenum];

            System.out.println("请按照学生序号顺序，依次按照以下格式来输入课程名称，课程成绩，课程学分和课程性质.\n"+"【输入“q”以结束】");
            System.out.println("课程名称 课程成绩 课程学分 课程是否为必修课(true)或(false)");
            for(int k=1;;k++){
                Double KeChengScore1=0.0;
                int KeChengCredit1=0;
                int totalcredit=0;
                int importantcredit=0;
                double totalscore=0;
                double importantscore=0;
                double GPA;
                double importantGPA;

                for(int i=0;i<coursenum;i++)
                {

                    String KeChengName=in.next();




                    // TODO: 2022/3/19  课程名称的输入检验(存在必要性存疑)




                    char testexit=KeChengName.charAt(0);

                    if(testexit=='q'&&KeChengName.length()==1){
                        System.out.print("欢迎您再次使用");
                        System.exit(0);
                    }else {


                        Double KeChengScore=in.nextDouble();
                        int KeChengCredit=in.nextInt();
                        boolean ShiFouBiXiu=in.nextBoolean();

                        KeChengScore1=KeChengScore;
                        KeChengCredit1=KeChengCredit;

                        if(KeChengScore<0||KeChengScore>100){
                            System.out.println("错误，请检查课程成绩");
                            break;
                        }else if(KeChengCredit<0){
                            System.out.println("错误，请检查课程学分");
                            break;
                        }


                        // TODO: 2022/3/19 其余输入检验








                        g[i]=new Course(KeChengName,KeChengScore,KeChengCredit,ShiFouBiXiu);
                        totalcredit+=g[i].credit();
                        totalscore+=g[i].GPA()*g[i].credit();
                        if(g[i].importance())
                        {
                            importantcredit+=g[i].credit();
                            importantscore+=g[i].GPA()*g[i].credit();
                        }
                    }

                }
                GPA=totalscore/totalcredit;
                importantGPA=importantscore/importantcredit;
                System.out.println(k+"号同学的必修课程GPA为："+String.format("%.2f",importantGPA));
                System.out.println(k+"号同学的全部课程GPA为："+String.format("%.2f", GPA));
                if(KeChengScore1<0||KeChengScore1>100||KeChengCredit1<0){
                   if(k==1){
                       k=0;
                   }else{
                       k-=1;
                   }
                }

            }

        }
        System.out.print("欢迎您再次使用");
    }
}